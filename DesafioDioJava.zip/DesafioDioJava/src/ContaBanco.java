import java.util.Scanner;

public class ContaBanco {

        public static void main(String[] args) {


        //importar a classe Scanner
        //Exibir mensagens para o usuário
        // obter pela classe Scanner os valores  digitados no terminal
        //exibir a mensagem da conta criada


        System.out.println("Hello World Isaac!");
            int conta;
            String agencia;
            String nome;
            double saldo;


            Scanner sc=new Scanner (System.in);
            System.out.println ("Olá! Digite o seu nome: ");
            nome= sc.next();
            System.out.println ("Agora digite o número da sua conta ");
            conta=sc.nextInt();
            System.out.println ("Digite o número da sua agência ");
            agencia=sc.next();
            System.out.println ("Digite o valor do seu depósito para a abertura da conta: ");
            saldo=sc.nextDouble();
            System.out.println ("Olá!" +nome+ " , obrigado por criar uma conta em nosso banco, sua agência é " +agencia+", conta: " +conta+ " e seu saldo R$ " +saldo+" já está disponível para saque. Banco Dio. ");
    }
}
